
  # 상품 리스트 정렬 변경

  This is a code bundle for 상품 리스트 정렬 변경. The original project is available at https://www.figma.com/design/iBiwpxMVnZtdU0NDHfIUA8/%EC%83%81%ED%92%88-%EB%A6%AC%EC%8A%A4%ED%8A%B8-%EC%A0%95%EB%A0%AC-%EB%B3%80%EA%B2%BD.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  