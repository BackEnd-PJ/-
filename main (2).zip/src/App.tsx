import { ChevronLeft, ChevronRight, Heart, ChevronDown, MapPin } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { useRef, useState } from 'react';
import Logo from './components/Logo';
import ProductDetail from './components/ProductDetail';
import SearchIcon from './components/SearchIcon';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./components/ui/dialog";

interface Product {
  id: number;
  image: string;
  title: string;
  price: string;
}

export default function App() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isLocationDialogOpen, setIsLocationDialogOpen] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('대방동');
  const [currentLocation, setCurrentLocation] = useState('');
  const [showAllFavorites, setShowAllFavorites] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 332; // Card width (320) + gap (12)
      const currentScroll = scrollContainerRef.current.scrollLeft;
      const targetScroll = direction === 'left' 
        ? currentScroll - scrollAmount 
        : currentScroll + scrollAmount;
      
      scrollContainerRef.current.scrollTo({
        left: targetScroll,
        behavior: 'smooth'
      });
    }
  };

  const getCurrentLocation = () => {
    // TODO: 지도 API 연동 시 아래 코드로 교체
    // navigator.geolocation.getCurrentPosition(
    //   async (position) => {
    //     const { latitude, longitude } = position.coords;
    //     // 카카오맵 API 예시:
    //     // const response = await fetch(`https://dapi.kakao.com/v2/local/geo/coord2address.json?x=${longitude}&y=${latitude}`, {
    //     //   headers: { Authorization: 'KakaoAK YOUR_API_KEY' }
    //     // });
    //     // const data = await response.json();
    //     // const locationName = data.documents[0].address.region_3depth_name; // 동 이름
    //     // setCurrentLocation(locationName);
    //   },
    //   (error) => {
    //     console.error('위치 정보를 가져올 수 없습니다:', error);
    //     setCurrentLocation('위치를 가져올 수 없습니다');
    //   }
    // );

    // 현재는 더미 데이터 사용
    const mockLocations = ['상도동', '노량진동', '흑석동', '동작동', '사당동'];
    const randomLocation = mockLocations[Math.floor(Math.random() * mockLocations.length)];
    setCurrentLocation(randomLocation);
  };

  const handleLocationSelect = (location: string) => {
    setSelectedLocation(location);
    setIsLocationDialogOpen(false);
  };

  const initialFavoriteItems: Product[] = [
    {
      id: 1,
      image: "https://images.unsplash.com/photo-1681295687974-8193601b499a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaWN5Y2xlJTIwYmlrZXxlbnwxfHx8fDE3NjI2MzMyMjF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "삼천리 자전거 팝니다",
      price: "150,000원"
    },
    {
      id: 2,
      image: "https://images.unsplash.com/photo-1557756731-a94d1274f2ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYW1waW5nJTIwY2hhaXJ8ZW58MXx8fHwxNzYyNjg5NjU2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "캠핑 의자 2개 세트",
      price: "20,000원"
    },
    {
      id: 3,
      image: "https://images.unsplash.com/photo-1675668409245-955188b96bf6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWNib29rJTIwbGFwdG9wfGVufDF8fHx8MTc2MjYyNjk4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "맥북 프로 16인치",
      price: "850,000원"
    },
    {
      id: 4,
      image: "https://images.unsplash.com/photo-1600269452121-4f2416e55c28?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuaWtlJTIwc25lYWtlcnN8ZW58MXx8fHwxNzYyNjAzNjA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "나이키 운동화 270",
      price: "45,000원"
    },
    {
      id: 5,
      image: "https://images.unsplash.com/photo-1571406487954-dc11b0c0767d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb29kJTIwbGFtcHxlbnwxfHx8fDE3NjI2ODk2NTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "무드등 인테리어 조명",
      price: "18,000원"
    },
    {
      id: 6,
      image: "https://images.unsplash.com/photo-1755620500895-b693799658ee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZXh0Ym9va3MlMjBzdGFja3xlbnwxfHx8fDE3NjI2Nzc2ODN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "전공책 7권 일괄",
      price: "35,000원"
    },
    {
      id: 7,
      image: "https://images.unsplash.com/photo-1679533662371-c0675c80e6f4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFkcGhvbmVzJTIwd2lyZWxlc3N8ZW58MXx8fHwxNzYyNjE0MTkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "소니 무선 헤드폰",
      price: "120,000원"
    },
    {
      id: 8,
      image: "https://images.unsplash.com/photo-1611648694931-1aeda329f9da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMG1vbml0b3J8ZW58MXx8fHwxNzYyNjA4MjQ0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      title: "27인치 모니터 삼성",
      price: "180,000원"
    }
  ];
  
  const [favoriteItems, setFavoriteItems] = useState<Product[]>(initialFavoriteItems);

  const handleToggleFavorite = (id: number) => {
    setFavoriteItems(prev => prev.filter(item => item.id !== id));
    setSelectedProduct(null);
  };

  // Filter items based on search query
  const filteredItems = searchQuery.trim() 
    ? favoriteItems.filter(item => 
        item.title.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : favoriteItems;

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
  };

  // Show product detail if selected
  if (selectedProduct) {
    return (
      <ProductDetail 
        product={selectedProduct} 
        onBack={() => setSelectedProduct(null)}
        onToggleFavorite={handleToggleFavorite}
      />
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 px-4 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-center">
          <div className="flex items-center gap-3">
            <Logo className="w-10 h-10" />
            <span className="text-red-600 font-extrabold text-2xl">A+</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        {/* Location Message */}
        <div className="text-center mb-6">
          <p className="text-gray-700 font-bold text-lg">
            📍 <span className="text-red-600 font-extrabold">**{selectedLocation}**</span>에서 물건 찾고 계신가요?
          </p>
        </div>

        {/* Search Bar */}
        <div className="flex gap-2 mb-8">
          <button 
            onClick={() => setIsLocationDialogOpen(true)}
            className="bg-red-600 text-white px-5 py-3 rounded-full flex items-center gap-2 hover:bg-red-700 transition-colors font-bold text-base"
          >
            <MapPin className="w-5 h-5" />
            <span>{selectedLocation}</span>
            <ChevronDown className="w-5 h-5" />
          </button>
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="검색어를 입력해주세요"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full border-2 border-gray-300 rounded px-5 py-3 pr-12 font-semibold text-base focus:border-red-600 focus:outline-none"
            />
            <SearchIcon className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 w-6 h-6" />
          </div>
        </div>

        {/* Favorite Items Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <span className="text-red-600 text-2xl leading-none">⭐</span>
              <span className="font-extrabold text-xl leading-none">{searchQuery ? '검색 결과' : 'OO님의 찜한 상품'}</span>
            </div>
            {!searchQuery && (
              <button 
                onClick={() => setShowAllFavorites(!showAllFavorites)}
                className="text-red-600 text-base font-bold"
              >
                {showAllFavorites ? '접기 ↑' : '전체 보기 →'}
              </button>
            )}
          </div>

          {!showAllFavorites && !searchQuery ? (
            /* Horizontal Scroll Container */
            <div className="relative">
              <button 
                onClick={() => scroll('left')}
                className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full shadow-lg p-2 hover:bg-gray-50"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              
              <div ref={scrollContainerRef} className="overflow-x-auto scrollbar-hide">
                <div className="flex gap-4 pb-2">
                  {filteredItems.map((item) => (
                    <div
                      key={item.id}
                      className="flex-shrink-0 w-96 bg-white border-2 border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
                    >
                      <div className="flex gap-4 p-4">
                        <div 
                          className="relative w-28 h-28 flex-shrink-0 cursor-pointer"
                          onClick={() => handleProductClick(item)}
                        >
                          <ImageWithFallback
                            src={item.image}
                            alt={item.title}
                            className="w-full h-full object-cover rounded"
                          />
                          <button 
                            className="absolute top-1 right-1 bg-white rounded-full p-1.5 shadow-sm hover:bg-gray-100"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleFavorite(item.id);
                            }}
                          >
                            <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                          </button>
                        </div>
                        <div 
                          className="flex-1 flex flex-col justify-center cursor-pointer"
                          onClick={() => handleProductClick(item)}
                        >
                          <p className="text-base mb-2 text-gray-800 font-bold">{item.title}</p>
                          <p className="text-red-600 font-extrabold text-lg">{item.price}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button 
                onClick={() => scroll('right')}
                className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full shadow-lg p-2 hover:bg-gray-50"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          ) : (
            /* Grid View for All Items */
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {filteredItems.length > 0 ? (
                filteredItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white border-2 border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
                  >
                    <div 
                      className="relative aspect-square cursor-pointer"
                      onClick={() => handleProductClick(item)}
                    >
                      <ImageWithFallback
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                      <button 
                        className="absolute top-2 right-2 bg-white rounded-full p-2 shadow-sm hover:bg-gray-100"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleToggleFavorite(item.id);
                        }}
                      >
                        <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                      </button>
                    </div>
                    <div 
                      className="p-4 cursor-pointer"
                      onClick={() => handleProductClick(item)}
                    >
                      <p className="text-base mb-2 text-gray-800 font-bold">{item.title}</p>
                      <p className="text-red-600 font-extrabold text-lg">{item.price}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-full text-center py-12">
                  <p className="text-gray-500 font-bold text-lg">검색 결과가 없습니다</p>
                </div>
              )}
            </div>
          )}
        </div>


      </main>

      {/* Location Selection Dialog */}
      <Dialog open={isLocationDialogOpen} onOpenChange={setIsLocationDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-extrabold text-xl">동네 설정</DialogTitle>
            <DialogDescription className="font-bold text-base">
              거래하고 싶은 동네를 선택해주세요
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 mt-4">
            {/* Current Location Button */}
            <button
              onClick={getCurrentLocation}
              className="w-full bg-red-600 text-white py-4 rounded-lg flex items-center justify-center gap-2 hover:bg-red-700 transition-colors font-bold text-base"
            >
              <MapPin className="w-6 h-6" />
              <span>현재 위치로 설정하기</span>
            </button>
            
            {currentLocation && (
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <p className="text-base text-gray-600 font-bold">현재 위치: <span className="text-red-600 font-extrabold">{currentLocation}</span></p>
                <button
                  onClick={() => handleLocationSelect(currentLocation)}
                  className="mt-2 text-base text-red-600 hover:underline font-bold"
                >
                  이 동네로 설정하기
                </button>
              </div>
            )}

            {/* Popular Locations */}
            <div className="border-t pt-4">
              <p className="text-base text-gray-600 mb-3 font-bold">내 주변 동네</p>
              <div className="grid grid-cols-2 gap-3">
                {['대방동', '상도동', '노량진동', '흑석동', '신대방동', '보라매동', '사당동', '동작동'].map((location) => (
                  <button
                    key={location}
                    onClick={() => handleLocationSelect(location)}
                    className={`py-3 px-4 rounded-lg border-2 transition-colors font-bold text-base ${
                      selectedLocation === location
                        ? 'bg-red-50 border-red-600 text-red-600 font-extrabold'
                        : 'bg-white border-gray-200 text-gray-700 hover:border-red-400'
                    }`}
                  >
                    {location}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <style jsx>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
