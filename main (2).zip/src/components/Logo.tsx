export default function Logo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Outer circle - gradient effect */}
      <circle 
        cx="50" 
        cy="50" 
        r="45" 
        fill="url(#gradient1)"
      />
      
      {/* Inner geometric shape - abstract A form */}
      <path
        d="M50 30 L70 65 L62 65 L58 56 L42 56 L38 65 L30 65 Z"
        fill="white"
        fillOpacity="0.95"
      />
      
      {/* A crossbar */}
      <rect x="44" y="52" width="12" height="6" fill="url(#gradient1)" />
      
      {/* Accent dot */}
      <circle cx="50" cy="72" r="3" fill="white" fillOpacity="0.9" />
      
      {/* Gradient definitions */}
      <defs>
        <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#DC2626" />
          <stop offset="100%" stopColor="#EF4444" />
        </linearGradient>
      </defs>
    </svg>
  );
}
