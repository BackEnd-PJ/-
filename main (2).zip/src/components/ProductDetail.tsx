import { ChevronLeft, ChevronRight, Heart, User } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';

interface Product {
  id: number;
  image: string;
  title: string;
  price: string;
}

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
  onToggleFavorite: (id: number) => void;
}

export default function ProductDetail({ product, onBack, onToggleFavorite }: ProductDetailProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  // Mock data for product details
  const images = [product.image, product.image, product.image]; // 실제로는 여러 이미지
  
  const productDetails = {
    category: '디지털기기',
    timeAgo: '8시간 전',
    description: '설명',
    views: 127,
    favorites: 23,
    seller: {
      name: '대학생',
      location: '대방동'
    }
  };

  const handleNextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 px-4 py-3 sticky top-0 bg-white z-10">
        <div className="max-w-6xl mx-auto flex items-center gap-4">
          <button onClick={onBack} className="hover:bg-gray-100 rounded-full p-1">
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="text-sm text-gray-600 font-medium">
            홈 &gt; 중고거래 &gt; {product.title}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Left - Image Gallery */}
          <div>
            <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden mb-4">
              <ImageWithFallback
                src={images[currentImageIndex]}
                alt={product.title}
                className="w-full h-full object-cover"
              />
              
              {/* Navigation Arrows */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={handlePrevImage}
                    className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg transition-colors"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button
                    onClick={handleNextImage}
                    className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg transition-colors"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>
                  <div className="absolute bottom-4 right-4 bg-black/50 text-white px-2 py-1 rounded text-sm font-medium">
                    {currentImageIndex + 1} / {images.length}
                  </div>
                </>
              )}
            </div>
            
            {/* Image Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-2">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentImageIndex(idx)}
                    className={`w-20 h-20 rounded overflow-hidden border-2 ${
                      idx === currentImageIndex ? 'border-red-600' : 'border-gray-200'
                    }`}
                  >
                    <ImageWithFallback
                      src={img}
                      alt={`${product.title} ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right - Product Info */}
          <div>
            <div className="mb-4">
              <div className="text-sm text-gray-500 mb-2 font-medium">
                {productDetails.category} · {productDetails.timeAgo}
              </div>
              <h1 className="text-gray-900 mb-4 font-bold">{product.title}</h1>
              <div className="text-red-600 font-bold mb-6">{product.price}</div>
            </div>

            {/* Description */}
            <div className="mb-6 pb-6 border-b">
              <p className="text-gray-700 whitespace-pre-line font-medium">
                {productDetails.description}
              </p>
            </div>

            {/* Stats */}
            <div className="text-sm text-gray-500 mb-6 font-medium">
              채팅 {productDetails.views} · 관심 {productDetails.favorites} · 조회 {productDetails.views}
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 mb-8">
              <button 
                onClick={() => onToggleFavorite(product.id)}
                className="border border-gray-300 rounded-lg px-4 py-3 hover:bg-gray-50"
              >
                <Heart className="w-6 h-6 fill-red-500 text-red-500" />
              </button>
              <button className="flex-1 bg-red-600 text-white rounded-lg px-4 py-3 hover:bg-red-700 transition-colors font-bold">
                메세지 보내기
              </button>
            </div>

            {/* Seller Info */}
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
                <div>
                  <div className="font-bold">{productDetails.seller.name}</div>
                  <div className="text-sm text-gray-500 font-medium">{productDetails.seller.location}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
